export default {
  content: [
    "./src/**/*.php",
    "./public_html/**/*.html",
    "./templates/**/*.php"
  ]
}